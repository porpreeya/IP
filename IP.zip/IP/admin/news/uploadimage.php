<?php


// $temp = explode(".", $_FILES["image"]["name"]);
// $newfilename = round(microtime(true)) . '.' . end($temp);

// //เช็คว่ามีรูปมั้ย
// if (!empty($_FILES['image']['tmp_name'])) {
//     // move_uploaded_file($tmp_name, "../../uploads/" . $newfilename );
//     move_uploaded_file($_FILES["image"]["tmp_name"], "../../uploads/" . $newfilename);
// }
// $objDB = mssql_select_db("intelle");

// $ID = $_POST['id'];


// $sql = ("UPDATE news SET image='{$newfilename}' WHERE ID='{$ID}'");

// $objQuery = mssql_query($sql);
// echo $newfilename ;
?>
