<?php

$question = iconv("utf-8", "tis-620", $_POST['question']);
$response = iconv("utf-8", "tis-620", $_POST['response']);

$dayout = date("Y-m-d");
$objDB = mssql_select_db("intelle");
$strSQL = "INSERT INTO ques";
$strSQL .= "(response,question,dateans)";
$strSQL .= "VALUES";
$strSQL .= "('" . $response . "','" . $question . "','" . $dateans . "')";
$strSQL .= mssql_query($strSQL);

?>

<script type="text/javascript">
    window.location = "../index.php?Menu=4&Submenu=showqa";
</script>