<style>  
.img {

    vertical-align: middle;
    border-style: none;
 width: 700px;
}
body{
    text-align: center;
    
}
</style>
<body >
<img src="../img/h2.png" class="img">
</body>